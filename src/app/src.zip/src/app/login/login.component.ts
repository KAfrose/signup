import { PlatformLocation } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm:any;
  status:any;
  constructor(private fb:FormBuilder, private us:UserService, location: PlatformLocation, private router:Router) {
    this.loginForm=this.fb.group({
      userName:[''],
      password:[''],
      showPassword:[false],
      rememberMe:[true]
    });
    location.onPopState(() => {
      //console.log('pressed back in add!!!!!');
      //this.router.navigateByUrl(‘/multicomponent’);
      history.forward();
      });
   }

   ngOnInit(): void {
    var rememberMe=this.loginForm.controls.rememberMe.value;
    if(rememberMe)
    {
      var userName=localStorage.getItem("userName");
      if(userName!=null)
      {
        this.loginForm.controls.userName.value=userName;        
      }
      var password=localStorage.getItem("password");
      if(password!=null)
        this.loginForm.controls.password.value=password;
    }
  }
   fnCall()
   {
    this.us.method1().subscribe((data)=>{
      console.log(data);
    });
    console.log("done")
   }

   fnLogin()
   {
     var userName=this.loginForm.controls.userName.value;
     var password=this.loginForm.controls.password.value;
     //check if "Remember me" is tick or not
     var rememberMe=this.loginForm.controls.rememberMe.value;
     if(rememberMe)
     {
       //store the user name and password in localStorage
       localStorage.setItem("userName",userName);
       localStorage.setItem("password",password);
     }else
     {
       localStorage.removeItem("userName");
       localStorage.removeItem("password");
     }
     console.log(userName+":"+password);
    const formData=new FormData();
    formData.append('userName',userName);
    formData.append('password',password);
    this.us.validateLogin(formData).subscribe(data=>{
      console.log(data);
      if(data==null)
        this.status="Login failed";
      else
      {
        this.router.navigate([{outlets:{'col3':['home']}}]);        
        // this.router.navigateByUrl('/(col3:home)');
      }
    });
  }

}
