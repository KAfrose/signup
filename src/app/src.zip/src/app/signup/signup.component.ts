import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { UserService } from '../user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  signupForm:any;
  gotp:any;
  otpError:any;
  constructor(private fb:FormBuilder, private us:UserService) {
    this.signupForm=this.fb.group({
      userName:[''],
      password:[''],
      cpassword:[''], 
      firstName:[''],
      lastName:[''],
      city:[''],
      mobile:[''],
      emailAddress:[''],
      generatedOtp:[''],
      enteredOtp:['']
    });
   }

  ngOnInit(): void {
    // this.signupForm.controls.generatedOtp.value='0000';
  }

  addUser()
  {
    var eotp=this.signupForm.controls.enteredOtp.value;
    alert('comparing '+eotp+' with '+this.gotp);
   // alert('adding...');
   if(eotp!=this.gotp)
   {
    this.otpError="Entered otp is invalid";
     return;
   }
    console.log(this.signupForm.value);
    this.us.addUser(this.signupForm.value).subscribe(data=>{
      console.log(data);
    })
  }

  fnGenerateOtp()
  {
    //under construction
    var emailAddress=this.signupForm.controls.emailAddress.value;
    console.log(emailAddress);
    this.us.generateOtp(emailAddress).subscribe((data)=>{
      console.log(data);
      this.gotp=data;      
    });
    // this.signupForm.controls.generatedOtp.value=this.gotp;
  }
}
